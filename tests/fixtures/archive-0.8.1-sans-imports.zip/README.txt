Archive Cuisine OS
==================
manifest.json  : format, version du format, date, décomptes, liste des fichiers avec empreinte SHA-256.
data/*.json    : un tableau JSON par magasin (identifiants stables, relations par identifiant).
files/<sha256>.<ext> : scans, photos et PDF originaux, nommés par leur empreinte.
Aucun secret d'accès n'est inclus. Cette archive est privée ; sa création ne publie rien.
